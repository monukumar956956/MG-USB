MG USB — शुरुआती Android APK प्रोजेक्ट

यह source project है, तैयार APK नहीं। APK बनाने के लिए AndroidIDE या Android SDK/Gradle build environment चाहिए।

इस शुरुआती वर्ज़न में:
- MG USB डार्क स्क्रीन और हरा टेक्स्ट
- Android Storage Access Framework से फोल्डर चुनना
- फोन की आंतरिक स्टोरेज की बुनियादी जानकारी
- Music/Backup फोल्डर चुनने के शॉर्टकट
- ऐप के अंदर History/Log
- Android document picker खोलना

सीमाएँ:
- Android के सुरक्षा नियमों के कारण ऐप USB को बिना अनुमति अपने आप नहीं पढ़ सकती।
- यह अभी USB में वास्तविक फाइल कॉपी/मूव, USB की सही क्षमता/health test, Bluetooth autoplay या physical repair नहीं करता।
- APK को फोन में इंस्टॉल किया जाता है, पेनड्राइव में नहीं।

AndroidIDE इस्तेमाल करते समय:
1. ZIP extract करें।
2. AndroidIDE में Open existing project चुनकर MG_USB फ़ोल्डर खोलें।
3. Build tools/JDK/SDK सेटअप पूरा करें।
4. Gradle sync होने दें।
5. assembleDebug / Quick Run करें।
6. APK app/build/outputs/apk/debug/app-debug.apk में मिलना चाहिए।

AndroidIDE प्रोजेक्ट archived / unmaintained बताया गया है; किसी भी IDE या build tool को केवल trusted source से डाउनलोड करें।

ऑनलाइन GitHub Actions से APK बनाने का विकल्प (मोबाइल से):
1. GitHub पर sign in करें और New repository बनाएँ (उदाहरण: MG-USB-Android)।
2. इस प्रोजेक्ट के अंदर की सभी फाइलें और .github/workflows/build-apk.yml भी repository में upload करें।
3. Repository में Actions टैब खोलें। “Build MG USB APK” workflow चुनें और Run workflow दबाएँ।
4. Build सफल होने पर उसी workflow run के नीचे Artifacts में MG-USB-debug-APK.zip डाउनलोड करें।
5. डाउनलोड की ZIP खोलें; अंदर app-debug.apk होगा। उसे फोन पर खोलकर इंस्टॉल करें। Android सुरक्षा पूछे तो केवल अपनी बनाई/विश्वसनीय APK के लिए अनुमति दें।

ध्यान दें: यह workflow GitHub account/repository की जरूरत रखता है और build result की गारंटी नहीं देता; build fail हो तो Actions log में error देखना होगा। यह debug APK है, Play Store release/signed production APK नहीं।
