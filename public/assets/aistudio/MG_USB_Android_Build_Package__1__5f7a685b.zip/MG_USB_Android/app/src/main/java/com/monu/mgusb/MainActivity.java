package com.monu.mgusb;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.os.StatFs;
import java.text.DateFormat;
import java.util.Date;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private SharedPreferences prefs;
    private static final int PICK_USB = 42;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("mgusb", MODE_PRIVATE);
        buildUI();
        log("MG USB app opened");
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        root.setBackgroundColor(0xFF07110C);
        scroll.addView(root);

        TextView logo = new TextView(this);
        logo.setText("MG USB"); logo.setTextSize(32); logo.setGravity(Gravity.CENTER);
        logo.setTextColor(0xFF39FF88); logo.setPadding(0, dp(10), 0, dp(4));
        logo.setTypeface(null, 1); root.addView(logo);
        TextView subtitle = new TextView(this);
        subtitle.setText("MULTI-TOOL • 16 GB EDITION"); subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextColor(0xFFB6C9BE); subtitle.setTextSize(12);
        root.addView(subtitle);
        status = new TextView(this); status.setText("तैयार • USB चुनकर शुरुआत करें");
        status.setTextColor(0xFFFFFFFF); status.setTextSize(15); status.setPadding(0, dp(22), 0, dp(12));
        root.addView(status);

        addButton("USB / पेनड्राइव चुनें", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, PICK_USB);
        });
        addButton("स्टोरेज जानकारी", v -> showStorage());
        addButton("Music फोल्डर खोलें", v -> openFolder("Music"));
        addButton("Backup फोल्डर खोलें", v -> openFolder("Backup"));
        addButton("History / लॉग देखें", v -> showHistory());
        addButton("फाइल मैनेजर खोलें", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivity(i);
        });
        TextView note = new TextView(this);
        note.setText("नोट: USB अनुमति Android के file picker से दें। यह शुरुआती संस्करण है; यह अपने आप Bluetooth से गाने नहीं चलाता और पेनड्राइव की physical repair नहीं कर सकता।");
        note.setTextColor(0xFFB6C9BE); note.setTextSize(12); note.setPadding(0, dp(20), 0, 0);
        root.addView(note);
        setContentView(scroll);
    }

    private void addButton(String text, View.OnClickListener click) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(15);
        b.setTextColor(0xFF39FF88); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF14271C));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.setMargins(0, dp(7), 0, dp(7));
        root.addView(b, p); b.setOnClickListener(click);
    }
    private void showStorage() {
        String s = "फोन की आंतरिक स्टोरेज:\n";
        try { StatFs f = new StatFs(getFilesDir().getAbsolutePath()); long free=f.getAvailableBytes()/1048576; long total=f.getTotalBytes()/1048576; s += "खाली: "+free+" MB / कुल: "+total+" MB"; }
        catch(Exception e) { s += "जानकारी उपलब्ध नहीं"; }
        status.setText(s); log("Storage info viewed");
        Toast.makeText(this, "USB की जगह देखने के लिए USB चुनें और Android file picker में जानकारी जाँचें।", Toast.LENGTH_LONG).show();
    }
    private void openFolder(String name) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.putExtra("android.provider.extra.INITIAL_URI", Uri.parse("content://com.android.externalstorage.documents/document/primary%3A"+name));
        startActivityForResult(i, PICK_USB); log(name+" folder requested");
    }
    private void showHistory() {
        String h = prefs.getString("history", "अभी कोई हिस्ट्री नहीं है।");
        status.setText("HISTORY / LOG\n\n"+h); log("History viewed");
    }
    private void log(String line) {
        String old = prefs.getString("history", "");
        String item = DateFormat.getDateTimeInstance().format(new Date()) + " — " + line;
        prefs.edit().putString("history", item + (old.isEmpty()?"":"\n"+old)).apply();
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req,res,data);
        if (req == PICK_USB && res == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION)); } catch(Exception ignored) {}
            status.setText("USB / फोल्डर चुना गया:\n"+uri.toString()+"\n\nAndroid ने जो अनुमति दी है, ऐप उसी सीमा में काम कर सकती है।");
            log("Storage location selected");
            Toast.makeText(this,"फोल्डर चुना गया",Toast.LENGTH_SHORT).show();
        }
    }
    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}
